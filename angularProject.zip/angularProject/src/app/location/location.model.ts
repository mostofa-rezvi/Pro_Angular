export class Location{
    
}