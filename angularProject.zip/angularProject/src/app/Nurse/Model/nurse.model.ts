export class NurseModel{

    id!: string;
    employeeid!: string;
    firstname!: string;
    lastname!: string;
    email!: string;
    phone!: string;
    address!: string;
    dob!: string;
    gender!: boolean;
    photo!: string;
    specialization!: string;
    department!: string;

}