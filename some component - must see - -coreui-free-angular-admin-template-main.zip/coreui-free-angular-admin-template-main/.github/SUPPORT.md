### Bug reports

See the [contributing guidelines](CONTRIBUTING.md) for sharing bug reports.

### How-to

For general troubleshooting or help getting started:

- Go to [Discussions](https://github.com/coreui/coreui-free-angular-admin-template/discussions).
