export interface Patient{
    patientId: number;
    name: string;
    contact: string;
}