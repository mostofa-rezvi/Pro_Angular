import { Component } from '@angular/core';

@Component({
  selector: 'app-bodypart',
  templateUrl: './bodypart.component.html',
  styleUrl: './bodypart.component.css'
})
export class BodypartComponent {

}
