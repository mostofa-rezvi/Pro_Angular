import { Component } from '@angular/core';

@Component({
  selector: 'app-editdoctor',
  templateUrl: './editdoctor.component.html',
  styleUrl: './editdoctor.component.css'
})
export class EditdoctorComponent {

}
